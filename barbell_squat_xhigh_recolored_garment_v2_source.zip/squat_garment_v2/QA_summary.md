# Squat garment revision QA

## Scope and preservation

The only intended scene change is `Black shorts` → `Same anatomical rig` → `use_deform_preserve_volume: true → false`, matching the human body. No shrinkwrap, inflation, recoloring, motion edit, camera change, or model replacement is applied.

- Original production scene SHA-256: `a7ffdcea3f3776b418aead09bd15a07f6d74be1a0da3eeea17ac590dd114ef74`.
- Original file remains unchanged.
- Hash-identical bind geometry/object transforms, all vertex colors, and all animation curves before/after the patch.
- Camera and visual settings identical, including 960 × 960, 16-sample Workbench antialiasing, Standard view transform, exposure 0.28.
- Top/mid/bottom raster comparisons localize visible changes to the shorts region (`qa/keypose_raster_change_bounds.json`).
- Compact reconstruction from the shared human was executed successfully. The same geometry, colors, animation curves, and camera settings match the production baseline exactly.

## Garment inspection

The original bottom-pose rear closeup has visible skin passing through the shorts near the lateral waist. Matching the body/cloth deformation methods removes those visible holes in front and rear closeups.

The sampled bottom-pose nearest-surface signed distance improves from −41.796 mm to −5.517 mm. There are 4,692 sampled shell vertices, including the inner solidified surface. Remaining negative distances include folded/hem geometry, where nearest-surface signed distance is ambiguous. This report does not assert numerical zero intersection. The delivered fit is accepted on the evaluated visual surface, with these residual measurements disclosed. The projection experiment retained in `garment_comparison.json` is diagnostic only and was not applied.

## Unchanged body and equipment checks

The existing all-frame validation remains applicable because those meshes and their motion are unchanged:

- 80 timeline frames plus endpoint 81; full-cycle vertex error: 0.000715 mm.
- Zero skin vertices inside the bar; minimum clearance 0.149 mm.
- Upper-back/bar minimum clearance 0.250 mm.
- Each finger/thumb wraps the bar with measured minimum clearance 0.150–0.210 mm.
- Planted soles move less than 0.001 mm; minimum sole height 0.130 mm.
- Bottom hip is 44.875 mm below the knee.
- Wrist-direction angle is approximately 15.4° throughout.

## Final raster review

See `qa/visual_review.json` for approval and `qa/gif_validation.json` for encoded duration, frame count, white corners, and framing checks. `output/all_80_frames.jpg` covers the complete motion; `qa/garment_before_after.jpg` shows original front/rear above matched front/rear.

The production loop retains the original smooth cosine-paced four-second squat. Primary muscles are red, secondary/support muscles blue, neutral tissue gray. The physical black shorts intentionally occlude the glutes and proximal thigh masks. No text or labels are drawn on the animation.
