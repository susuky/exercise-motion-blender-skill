# Barbell squat: garment revision v2

This version fixes visible skin-through-shorts in the original deep squat. The shorts now use the same armature deformation method as the body. No additional garment inflation or surface projection is applied. The original motion, body, equipment, muscle colors, camera, framing, and raster quality are unchanged.

## Outputs

- `output/barbell_squat_xhigh_recolored_garment_v2.gif`: 960 × 960, white background, four-second continuous loop.
- `output/representative.png`: full-resolution bottom pose.
- `QA_summary.md` and `qa/`: measured checks and visual review.
- `COLOR_MAPPING.md`: unchanged anatomical color roles.

The GIF is delivered separately. The compact source archive contains the scripts, exact motion channels, representative image, and QA, without duplicating the shared human or full Blender scenes.

## Rebuild from the shared human

Requires Blender 4.3.2, Python 3, Pillow, and NumPy. Set `HUMAN_BLEND` to the shared `improved_human.blend` asset described in `assets/SHARED_BASE.md`. Run:

```sh
HUMAN_BLEND=/path/to/improved_human.blend python build_from_shared.py
OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 LP_NUM_THREADS=1 blender -b -t 1 --python-exit-code 1 --python render.py
python package.py
```

`BLENDER` may specify the Blender executable. The rebuild executes the included original squat construction, toe-aligned knee refinement, anatomical recoloring, exact animation restoration, and garment-only patch. It needs no previously generated exercise scene. It was tested against the shared human and reproduced the original bind geometry, vertex colors, animation curves, and camera settings exactly (`qa/rebuild_verification.json`).

For an existing exact original production scene, `SQUAT_ORIGINAL_BLEND=/path/to/original.blend blender -b -t 2 --python patch_scene.py` applies the versioned patch directly. Its exact SHA-256 is recorded in `qa/revision_identity.json`. The input file is never overwritten. The full output `.blend` remains local by default.

`render.py -- --preview` renders top, midpoint, and bottom only. Full rendering uses 41 unique poses and verifies the symmetry of all animation curves before reusing the reverse poses. Each of the 80 timeline frames lasts 50 ms.

The optional `validate_geometry.py` reruns dense body/bar/foot checks. `validate_garment.py` reproduces the four-pose signed-distance audit; add `-- --stills` for original/matched closeups. These read-only validation scripts never overwrite the scene.

## Garment QA interpretation

The original bottom-pose shorts had visible skin breakthrough and sampled signed overlap of 41.8 mm. Matching deformation methods removes the visible defect. Residual nearest-surface signed distances reach about −5.5 mm near cloth hems and inner folds; this metric is ambiguous there and is not presented as proof of collision-free geometry. Matched front/back closeups are inspected alongside the complete animation. The separate surface-projection experiment in the audit JSON was diagnostic only and is not used in this revision.

The original body/bar/foot checks are retained because their geometry and motion are hash-identical. Black shorts naturally cover the glute and proximal-thigh muscle masks.
