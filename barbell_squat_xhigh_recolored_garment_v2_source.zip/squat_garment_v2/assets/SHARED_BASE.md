# Shared human dependency

Use the current improved_human.blend asset via HUMAN_BLEND. SHA-256: 8cf1d47956499f4a700263ae7db4afd7ae7a63f275f03056b5459f8fd826daf2.

The original squat asset has a different serialized file hash but exactly matching body/cloth bind coordinates, weights, vertex colors, modifiers and rig rest matrices. See qa/shared_asset_compatibility.json. No original full exercise scene is required for the compact rebuild path.
