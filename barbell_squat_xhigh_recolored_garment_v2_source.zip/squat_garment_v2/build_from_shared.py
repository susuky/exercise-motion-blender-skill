"""Rebuild using only these compact sources and the shared HUMAN_BLEND asset."""
import os,subprocess,json,hashlib
from pathlib import Path
D=Path(__file__).resolve().parent;env=os.environ.copy();assert Path(env['HUMAN_BLEND']).exists(),'Set HUMAN_BLEND to the shared improved_human.blend file.'
assert hashlib.sha256(Path(env['HUMAN_BLEND']).read_bytes()).hexdigest()=='8cf1d47956499f4a700263ae7db4afd7ae7a63f275f03056b5459f8fd826daf2','The shared human differs from the verified asset; use the documented version.'
env.update(OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',LP_NUM_THREADS='2');blender=env.get('BLENDER','blender')
def run(script,*args):
 available=int(next(line.split()[1] for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:'))) if Path('/proc/meminfo').exists() else 2**30
 assert available>1048576,'Wait for at least 1 GiB available RAM before rebuilding.'
 subprocess.run([blender,'-b','-t','2','--python-exit-code','1','--python',str(script)]+(['--']+list(args) if args else []),env=env,check=True)
run(D/'rebuild/base_squat/build_scene.py');run(D/'rebuild/base_squat/scripts/refine_leg_tracking.py')
env['SQUAT_BASE_SCENE']=str(D/'rebuild/base_squat/output/barbell_squat_xhigh.blend');run(D/'rebuild/color_revision/recolor.py','squat','patch')
env['SQUAT_ORIGINAL_BLEND']=str(D/'rebuild/color_revision/squat/output/barbell_squat_xhigh_recolored.blend');run(D/'restore_motion.py');env['ALLOW_REBUILT_BASELINE']='1';run(D/'patch_scene.py')
print('Scene rebuilt from the shared human; next run render.py and package.py.')
