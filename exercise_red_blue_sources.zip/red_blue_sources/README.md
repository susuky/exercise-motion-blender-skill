# 紅／藍肌群版來源

先執行根目錄 `blender -b --python rebuild_human.py` 產生共用人體。每個範例目錄保留原建模、渲染、編碼、驗證程式與功能映射文件。

新臥推與兩種硬舉的 build_scene.py 已含紅／藍標示。側平舉、戰繩、深蹲、滑輪下拉先建立原場景，再用 recolor_raise_rope 或 recolor_squat_pulldown 內的腳本套用新版色彩；它們依 examples 下原有相對目錄尋找場景。

最終 GIF 編碼採用 recolor 目錄的新版 package 程式，保留紅／藍色盤與純白背景。每個範例的 README 和腳本開頭有命令。完整 Blender 場景與渲染影格在執行時產生。

封裝時已檢查 Python 語法及 ZIP CRC；本精簡整包沒有重新渲染全部動作。來源 QA 是各動作先前實際執行的結果。
