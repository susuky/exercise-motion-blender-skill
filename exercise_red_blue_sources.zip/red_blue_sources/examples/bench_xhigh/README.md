# 健力槓鈴臥推：xhigh

960 × 960、20 fps 時間軸、4 秒無限循環。白底、無文字，完整人體、槓鈴及臥推架入鏡。

## 成品

- `output/barbell_bench_press_xhigh.gif`：完整動畫
- `output/representative.png`：槓鈴觸胸代表幀
- `output/barbell_bench_press_xhigh.blend`：完整自含場景、密集人體、材質、骨架與動作
- `output/animation_contact_sheet.jpg`、`output/all_80_frames.jpg`：全動作檢視圖
- `qa/`：手掌包握、胸口接觸、足底、側面支撐及逐幀數值檢查

## 動作

雙腳平貼地面，臀部、上背和頭部支撐在平板上，腰背保留適度拱起。雙手以 75 公分握心間距完整包握直槓，控制下降至下胸，停頓 0.35 秒，再向上及向肩膀方向推回鎖定位置。鎖定時肘角約 174°。下降與上推各 1.65 秒，頂端停留 0.35 秒。

人體沿用既有 856,194 頂點連續蒙皮模型與肌肉浮雕。主要作用的胸大肌標示紅色；輔助作用的肱三頭肌與三角肌前束標示藍色，其餘維持灰色。共用線性 RGB 基色為紅色 `(0.72, 0.045, 0.03)`、藍色 `(0.035, 0.18, 0.72)`、灰色 `(0.73, 0.75, 0.76)`，保留肌束陰影與平滑邊界。握槓使用雙節手臂解算及個別指骨包覆，再依實際蒙皮表面擬合各指與槓面的距離。足底及肩胛接觸區固定，避免動作時滑移。

## 重製

Blender 4.3.2、Python 3、Pillow、NumPy。

共享人體由 `HUMAN_BLEND` 環境變數指定；在 repo 中預設讀取 `../../assets/improved_human.blend`；若不存在，再尋找相鄰 `../pulldown_xhigh/assets/improved_human.blend` 或本資料夾 `assets/improved_human.blend`。可先由 repo 根目錄的 `rebuild_human.py` 建立共享模型。詳見 `assets/SHARED_BASE.md`。

    HUMAN_BLEND=/path/to/improved_human.blend blender -b -t 3 --python build_scene.py -- --stills
    blender -b -t 3 --python scripts/render.py
    blender -b -t 2 --python scripts/render.py -- --qa
    blender -b -t 2 --python scripts/validate_all.py
    python package.py

使用已交付的完整 `.blend` 時，可直接從第二行執行。場景沒有外部貼圖相依。渲染器為 Workbench、16 級抗鋸齒。相同姿勢重複使用相同渲染影格，GIF 採全片共用色盤，靜止停頓合併為較長顯示時間。

## 資產

基礎人體為既有 MPFB 衍生 CC0 資產；授權全文位於 `assets/LICENSE.ASSETS.md`。本次新增臥推板、支架、槓鈴和動作。共享模型及完整場景分開存放，避免每個動作原始碼包都重複收錄大型人體檔案。
