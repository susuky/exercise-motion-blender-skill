# Shared human asset

In the published repo, use root `rebuild_human.py` to generate root `assets/improved_human.blend`. The example resolves it at `../../assets/improved_human.blend`. Local compatibility also supports the existing `pulldown_xhigh/assets/improved_human.blend`.

SHA-256: 8cf1d47956499f4a700263ae7db4afd7ae7a63f275f03056b5459f8fd826daf2

Set `HUMAN_BLEND` to its location, or place it at `assets/improved_human.blend`. The delivered completed bench scene is self-contained and can be rendered without the shared base.
