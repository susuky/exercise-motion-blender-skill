from PIL import Image,ImageDraw,ImageOps
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];QA=ROOT/'qa'
paths=sorted(QA.glob('*.png'));w=400;h=425;cols=3;rows=(len(paths)+cols-1)//cols
canvas=Image.new('RGB',(w*cols,h*rows),'white');draw=ImageDraw.Draw(canvas)
for k,p in enumerate(paths):
 im=Image.open(p).convert('RGB').resize((w,w),Image.Resampling.LANCZOS);x=(k%cols)*w;y=(k//cols)*h;canvas.paste(im,(x,y+25));draw.text((x+10,y+7),p.stem,fill=(30,30,30))
canvas.save(QA/'contact_qa_sheet.jpg',quality=95)
