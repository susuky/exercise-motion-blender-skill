"""Restore shared-base colours, then apply current colours to the verified motion."""
import bpy,math,os,numpy as np
from mathutils import Vector as V
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output'
candidates=[Path(os.environ['HUMAN_BLEND'])] if 'HUMAN_BLEND' in os.environ else [ROOT.parents[1]/'assets/improved_human.blend',ROOT.parent/'pulldown_xhigh/assets/improved_human.blend',ROOT.parents[1]/'assets/improved_human.blend']
BASE=next((p for p in candidates if p.exists()),candidates[0])
bpy.ops.wm.open_mainfile(filepath=str(BASE));a=bpy.data.objects['Human'].data.color_attributes['Anatomical fibres'];colors=np.empty(len(a.data)*4,dtype=np.float32);a.data.foreach_get('color',colors)
bpy.ops.wm.open_mainfile(filepath=str(OUT/'barbell_bench_press_xhigh.blend'))
h=bpy.data.objects['Human'];bones=bpy.data.objects['Human.rig'].data.bones;h.data.color_attributes['Anatomical fibres'].data.foreach_set('color',colors)
s=(ROOT/'build_scene.py').read_text();exec(s[s.index('# Exercise colours:'):s.index('# Fixed plantar')])
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'barbell_bench_press_xhigh.blend'),compress=True)
scene=bpy.context.scene;scene.frame_set(37);scene.render.filepath=str(OUT/'representative.png');bpy.ops.render.render(write_still=True)
print('COLOURS UPDATED',flush=True)
