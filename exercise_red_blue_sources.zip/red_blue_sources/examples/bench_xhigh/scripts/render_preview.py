import bpy
from pathlib import Path
from mathutils import Vector as V
r=Path(__file__).resolve().parents[1];bpy.ops.wm.open_mainfile(filepath=str(r/'output/barbell_bench_press_xhigh.blend'));s=bpy.context.scene
for f in [1,37]:
 s.frame_set(f);s.render.filepath=str(r/'output'/f'preview_{f:03d}.png');bpy.ops.render.render(write_still=True)
s.frame_set(37);cam=s.camera;t=V((0,.15,.59));cam.location=t+V((1.7,-1.8,2));cam.rotation_euler=(t-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=.85;s.render.filepath=str(r/'qa/chest_boundary_closeup.png');bpy.ops.render.render(write_still=True)
