"""Execute an extracted compact package from an unrelated cwd, with no rendering."""
from pathlib import Path
import os,sys,json,zipfile,tempfile,subprocess,hashlib
root=Path(sys.argv[1]).resolve();archive=Path(sys.argv[2]).resolve();meta=json.load(open(root/'metadata.json')) if (root/'metadata.json').exists() else {};sid=meta.get('stable_id',meta.get('asset_id','barbell_bench_press_xhigh'));base=Path(os.environ.get('HUMAN_BLEND','/workspace/scratch/2a666e37abc2/muscle_comparison/pulldown_xhigh/assets/improved_human.blend'))
work=Path(tempfile.mkdtemp(prefix='source-check-',dir='/tmp'))
with zipfile.ZipFile(archive) as z:
 assert not any(n.endswith('.blend') for n in z.namelist());z.extractall(work)
entry=next(work.rglob('build_scene.py'));env=dict(os.environ,HUMAN_BLEND=str(base),OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1');cmd=['blender','-b','-t','1','--python',str(entry)];run=subprocess.run(cmd,cwd='/tmp',env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);(root/'qa/source_entrypoint_build.log').write_text(run.stdout);scene=entry.parent/'output'/(sid+'.blend');motion=entry.parent/'output/motion.json'
assert run.returncode==0 and 'Traceback (most recent call last)' not in run.stdout and scene.exists() and motion.exists(),run.stdout[-3000:]
a=json.load(open(root/'output/motion.json'));b=json.load(open(motion));assert len(a)==len(b)==81
maxdelta=max(abs(x-y) for f,g in zip(a,b) for k in f['joints'] for x,y in zip(f['joints'][k],g['joints'][k]));assert maxdelta<1e-6,maxdelta
report={'passed':True,'test':'Actual packaged Blender entrypoint executed from unrelated cwd /tmp; full scene built without rendering','command':cmd,'extracted_root':str(entry.parent),'shared_asset_sha256':hashlib.sha256(base.read_bytes()).hexdigest(),'input_archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'created_scene_bytes':scene.stat().st_size,'motion_frames_compared':len(a),'motion_max_coordinate_delta_m':maxdelta,'reproduced_scene_path':str(scene)};(root/'qa/compact_source_test.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
