import bpy,numpy as np,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
bpy.ops.wm.open_mainfile(filepath=str(ROOT/'output/barbell_bench_press_xhigh.blend'))
h=bpy.data.objects['Human'];n=len(h.data.vertices);p=np.empty(n*3);h.data.vertices.foreach_get('co',p);p=p.reshape(-1,3);c=np.empty(n*4);h.data.color_attributes['Anatomical fibres'].data.foreach_get('color',c);c=c.reshape(-1,4)
red=(c[:,0]>c[:,1]*1.25)&(c[:,0]>c[:,2]*1.25);blue=(c[:,2]>c[:,0]*1.25)&(c[:,2]>c[:,1]*1.25);legs=p[:,2]<1.0
r={'primary_red':['pectoralis major'],'secondary_blue':['triceps brachii','anterior deltoid'],'other_regions':'gray','base_linear_rgb':{'red':[.72,.045,.03],'blue':[.035,.18,.72],'gray':[.73,.75,.76]},'red_vertex_count':int(red.sum()),'blue_vertex_count':int(blue.sum()),'red_rest_bounds_m':[p[red].min(axis=0).tolist(),p[red].max(axis=0).tolist()],'blue_rest_bounds_m':[p[blue].min(axis=0).tolist(),p[blue].max(axis=0).tolist()],'highlighted_leg_vertex_count':int(((red|blue)&legs).sum()),'secondary_mask':'upper-arm skin weights gate the geometric triceps and front-deltoid masks'}
assert r['highlighted_leg_vertex_count']==0
(ROOT/'qa/muscle_colors.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
