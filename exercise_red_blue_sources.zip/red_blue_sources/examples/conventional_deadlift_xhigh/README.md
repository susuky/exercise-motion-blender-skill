# 傳統槓鈴硬舉：xhigh

960 × 960、80 幀、20 fps、4 秒無限循環。白底，動畫沒有文字。

![傳統硬舉：主要肌群紅色、次要肌群藍色](output/conventional_deadlift_xhigh.gif)

## 交付檔案

- `output/conventional_deadlift_xhigh.gif`：完整動畫
- `output/representative.png`：地面起始姿勢
- `output/conventional_deadlift_xhigh.blend`：高細節人體、槓鈴、骨架與完整動畫
- `output/animation_contact_sheet.jpg`、`output/all_80_frames.jpg`：逐階段與全部影格
- `qa/grip_*`：兩手正面及背面握槓特寫
- `qa/feet_*`、`qa/side_*`：腳底及側面動作檢查
- `qa/bar_path_*`：暫隱槓片的側面槓路檢查
- `qa/all_frame_geometry_validation.json`：81 幀密集蒙皮與接觸檢查
- `output/gif_validation.json`：GIF 規格及逐幀畫面邊界檢查

## 重製

環境：Blender 4.3.2、Python 3、Pillow、NumPy。

    blender -b -t 2 --python build_scene.py -- --stills
    blender -b -t 2 --python scripts/render.py
    blender -b -t 2 --python scripts/render.py -- --qa
    blender -b -t 2 --python scripts/validate_all.py
    blender -b -t 2 --python scripts/render.py -- --path-qa
    blender -b -t 1 --python scripts/validate_curves.py
    blender -b -t 1 --python scripts/validate_colors.py
    python scripts/make_qa_sheets.py
    python package.py --archive
    python scripts/validate_delivery.py

已有完整 `.blend` 時，可直接從第二行重新渲染。

## 動作與人體

沿用 856,194 頂點連續蒙皮人體，保留胸腹、手臂、腿部肌肉浮雕及肌束紋理。黑色短褲為獨立蒙皮布料殼。本版本以紅色標示臀大肌／股四頭肌區域，藍色標示腿後肌群／豎脊肌區域，其餘為灰色。功能角色、來源與衣物遮擋說明見 `MUSCLE_MAPPING.md`。

傳統硬舉設定為約 28 公分踝距、腳尖外開 7°，雙手位於腿外側，握距約 58 公分。雙臂保持伸直，五指持續環繞槓軸，肩、肘、腕及指骨皆納入姿勢求解。腳底固定在地面，膝與髖隨槓鈴上升逐步伸展，頂端軀幹直立。下降為上升的精確時間反向，兩端速度為零。

槓鈴採 29 mm 握持段、50 mm 套筒、450 mm 直徑槓片及鎖環。起始槓軸高度由槓片半徑決定，雙側槓片底緣接觸地面。各段握槓表面不重疊。

固定後側三分之四視角，完整人體與槓鈴全程入鏡。Workbench 16 級抗鋸齒，GIF 全片使用共用色盤。為節省重複計算，渲染 41 個相位後，精確反向排列成全部 80 幀；Blender 內保留完整的 81 幀閉合時間軸。

## 資產

基礎人體為先前樣本使用的 MPFB 衍生 CC0 資產，授權全文位於 `assets/LICENSE.ASSETS.md`。場景沒有外部貼圖或網路相依。
