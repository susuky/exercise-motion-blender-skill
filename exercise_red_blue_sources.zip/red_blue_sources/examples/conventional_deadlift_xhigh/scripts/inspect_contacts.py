"""Write per-pose nearest leg surface, useful when editing the bar path."""
import bpy,numpy as np,json
from pathlib import Path
P=Path(__file__).resolve().parents[1];bpy.ops.wm.open_mainfile(filepath=str(P/'output/conventional_deadlift_xhigh.blend'))
h=bpy.data.objects['Human'];s=bpy.context.scene;bar=bpy.data.objects['Loaded straight barbell'];r=np.array([v.co[:] for v in h.data.vertices]);mask=(r[:,2]>.1)&(r[:,2]<.9)&(abs(r[:,0])<.3);ids=np.where(mask)[0];out=[]
for f in [1,11,15,21,26,31,36,41]:
 s.frame_set(f);ev=h.evaluated_get(bpy.context.evaluated_depsgraph_get());me=ev.to_mesh();a=np.empty(len(me.vertices)*3);me.vertices.foreach_get('co',a);a=a.reshape(-1,3);d=np.hypot(a[mask,1]-bar.location.y,a[mask,2]-bar.location.z);i=ids[d.argmin()];out.append({'frame':f,'bar':list(bar.location),'nearest_leg_skin':a[i].tolist(),'clearance':float(d.min()-.0145)});ev.to_mesh_clear()
(P/'qa/nearest_leg_contacts.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
