import bpy,numpy as np
from pathlib import Path
P=Path(__file__).resolve().parents[1];bpy.ops.wm.open_mainfile(filepath=str(P/'assets/improved_human.blend'))
o=bpy.data.objects['Black shorts'];a=np.array([v.co[:] for v in o.data.vertices]);print('SHORTS',len(a),len(o.data.polygons),a.min(0),a.max(0));print('MODIFIERS',[(m.name,m.type) for m in o.modifiers]);print('GROUPS',len(o.vertex_groups));print('MATERIALS',[m.name for m in o.data.materials]);print('HUMAN',[m.name for m in bpy.data.objects['Human'].data.materials]);print('COLORS',[(x.name,x.domain,x.data_type) for x in bpy.data.objects['Human'].data.color_attributes])
