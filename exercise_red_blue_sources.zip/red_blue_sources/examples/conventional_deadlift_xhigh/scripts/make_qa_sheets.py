"""Combine all rendered contact views into inspection sheets."""
from PIL import Image
from pathlib import Path
p=Path(__file__).resolve().parents[1]/'qa'
for view in ['grip','grip_front']:
 sheet=Image.new('RGB',(1440,960),'white')
 for k,(side,f) in enumerate([(s,f) for s in ['l','r'] for f in [1,15,41]]):
  im=Image.open(p/f'{view}_{side}_{f:03}.png').convert('RGB').resize((480,480),Image.Resampling.LANCZOS);sheet.paste(im,((k%3)*480,(k//3)*480))
 sheet.save(p/f'{view}_contact_sheet.jpg',quality=94)
sheet=Image.new('RGB',(1440,960),'white')
for k,(view,f) in enumerate([(view,f) for view in ['feet','side'] for f in [1,15,41]]):
 im=Image.open(p/f'{view}_{f:03}.png').convert('RGB').resize((480,480),Image.Resampling.LANCZOS);sheet.paste(im,((k%3)*480,(k//3)*480))
sheet.save(p/'support_contact_sheet.jpg',quality=94)
sheet=Image.new('RGB',(2400,480),'white')
for k,f in enumerate([1,15,21,31,41]):
 im=Image.open(p/f'bar_path_{f:03}.png').convert('RGB').resize((480,480),Image.Resampling.LANCZOS);sheet.paste(im,(k*480,0))
sheet.save(p/'bar_path_contact_sheet.jpg',quality=94)
sheet=Image.new('RGB',(1800,600),'white')
for k,(view,side,f) in enumerate([(v,s,f) for v in ['grip','grip_front'] for s in ['l','r'] for f in [1,15,41]]):
 im=Image.open(p/f'{view}_{side}_{f:03}.png').convert('RGB').resize((300,300),Image.Resampling.LANCZOS);sheet.paste(im,((k%6)*300,(k//6)*300))
sheet.save(p/'grips_review.jpg',quality=94)
