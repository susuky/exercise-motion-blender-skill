"""Validate bind-space color regions and the unchanged black garment."""
import bpy,numpy as np,json
from pathlib import Path
P=Path(__file__).resolve().parents[1];bpy.ops.wm.open_mainfile(filepath=str(P/'output/conventional_deadlift_xhigh.blend'))
h=bpy.data.objects['Human'];r=np.array([v.co[:] for v in h.data.vertices]);c=np.array([x.color[:] for x in h.data.color_attributes['Anatomical fibres'].data])[:,:3]
red=(c[:,0]>c[:,1]+.08)&(c[:,0]>c[:,2]+.08);blue=(c[:,2]>c[:,0]+.08)&(c[:,2]>c[:,1]+.08)
# The knee centers are at ~0.503 m in bind space; the stop bands end above them.
low=r[:,2]<.510
out={'primary_red_vertices':int(red.sum()),'secondary_blue_vertices':int(blue.sum()),'red_vertices_below_bind_knee':int((red&low).sum()),'blue_vertices_below_bind_knee':int((blue&low).sum()),'red_bind_bounds_m':[r[red].min(0).tolist(),r[red].max(0).tolist()],'blue_bind_bounds_m':[r[blue].min(0).tolist(),r[blue].max(0).tolist()],'shorts_object_name':bpy.data.objects['Black shorts'].name,'shorts_base_color':list(bpy.data.objects['Black shorts'].data.materials[0].diffuse_color),'primary_roles':['gluteus_maximus_region_covered_by_unchanged_shorts','quadriceps_region'],'secondary_roles':['hamstrings_region','erector_spinae_region'],'classification':'qualitative teaching roles, not activation intensity; gray is not inactive','anatomical_accuracy':'bone-relative regional masks, not individually segmented muscles'}
assert out['red_vertices_below_bind_knee']==0 and out['blue_vertices_below_bind_knee']==0
(P/'qa/color_validation.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
