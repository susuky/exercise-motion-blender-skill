"""Check transform curves for quaternion sign jumps between samples."""
import bpy,json
from pathlib import Path
P=Path(__file__).resolve().parents[1];bpy.ops.wm.open_mainfile(filepath=str(P/'output/conventional_deadlift_xhigh.blend'))
s=bpy.context.scene;r=bpy.data.objects['Human.rig'];prev={};minimum=1.;bad=[]
for f in range(1,82):
 s.frame_set(f)
 for b in r.pose.bones:
  q=b.rotation_quaternion.copy()
  if b.name in prev:
   dot=q.dot(prev[b.name]);minimum=min(minimum,dot)
   if dot<0:bad.append([f,b.name,dot])
  prev[b.name]=q
result={'adjacent_quaternion_min_dot':minimum,'negative_dot_count':len(bad),'negative_dot_samples':bad}
(P/'qa/curve_validation.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
