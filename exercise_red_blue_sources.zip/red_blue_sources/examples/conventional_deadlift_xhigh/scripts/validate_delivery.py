"""Validate decoded GIF colors, palette error, margins and source ZIP integrity."""
from pathlib import Path
from PIL import Image
import json,zipfile,numpy as np,hashlib
P=Path(__file__).resolve().parents[1];G=P/'output/conventional_deadlift_xhigh.gif';Z=P/'conventional_deadlift_xhigh_reproducible_source.zip'
im=Image.open(G);errors=[];corners=[];reds=[];blues=[]
for k in range(im.n_frames):
 im.seek(k);rgb=im.convert('RGB');a=np.array(rgb);b=np.array(Image.open(P/f'output/frame_{k+1:03}.png').convert('RGB'));errors.append(float(np.abs(a.astype(float)-b).mean()));corners.append(all(tuple(a[y,x])==(255,255,255) for y,x in [(0,0),(959,0),(0,959),(959,959)]));ai=a.astype(int);reds.append(int(((ai[:,:,0]>ai[:,:,1]+25)&(ai[:,:,0]>ai[:,:,2]+25)).sum()));blues.append(int(((ai[:,:,2]>ai[:,:,0]+25)&(ai[:,:,2]>ai[:,:,1]+25)).sum()))
 if k==20:rgb.save(P/'qa/decoded_gif_frame_021.png')
with zipfile.ZipFile(Z) as z:bad=z.testzip();count=len(z.namelist())
j=json.load(open(P/'output/gif_validation.json'));bounds=j['frames'];report={'decoded_gif_white_corners_all_frames':all(corners),'decoded_primary_red_pixel_range':[min(reds),max(reds)],'decoded_secondary_blue_pixel_range':[min(blues),max(blues)],'mean_absolute_palette_error_rgb':sum(errors)/len(errors),'worst_frame_mean_absolute_palette_error_rgb':max(errors),'minimum_framing_margin_px':min(min(b['bounds'][0],b['bounds'][1],960-b['bounds'][2],960-b['bounds'][3]) for b in bounds),'archive_bad_member':bad,'archive_member_count':count,'source_archive_bytes':Z.stat().st_size,'source_archive_sha256':hashlib.sha256(Z.read_bytes()).hexdigest(),'gif_bytes':G.stat().st_size,'gif_sha256':hashlib.sha256(G.read_bytes()).hexdigest()}
assert all(corners) and min(reds)>100 and min(blues)>100 and bad is None
(P/'qa/final_delivery_validation.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
