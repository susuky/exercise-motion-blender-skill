import bpy,numpy as np
bpy.ops.wm.open_mainfile(filepath='/workspace/scratch/2a666e37abc2/muscle_comparison/pulldown_xhigh/output/lat_pulldown_xhigh.blend');bpy.context.scene.frame_set(41)
for name in ['Human','Black shorts']:
 h=bpy.data.objects[name];ev=h.evaluated_get(bpy.context.evaluated_depsgraph_get());me=ev.to_mesh();a=np.empty(len(me.vertices)*3);me.vertices.foreach_get('co',a);a=a.reshape(-1,3)
 print(name,'verts',len(a))
 pad=(abs(a[:,0])>.045)&(abs(a[:,0])<.30)&(a[:,2]<.85)
 for z in [.68,.70,.72,.74,.76,.78]:print('pad',z,'minrad',np.min(np.sqrt((a[pad,1]+.31)**2+(a[pad,2]-z)**2)))
 for ya,yb in [(-.165,.195),(-.10,.14)]:
  seat=(abs(a[:,0])<.21)&(a[:,1]>ya)&(a[:,1]<yb)&(a[:,2]>.30)&(a[:,2]<.60);print('seat minimum',np.min(a[seat,2]))
