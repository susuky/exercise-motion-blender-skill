import bpy,json
bpy.ops.wm.open_mainfile(filepath='/workspace/scratch/2a666e37abc2/muscle_comparison/xhigh/output/lateral_raise_xhigh.blend')
print('OBJECTS',[(o.name,o.type) for o in bpy.data.objects])
r=bpy.data.objects['Human.rig']
for b in r.data.bones:
 print(b.name,'head',tuple(round(x,4) for x in b.head_local),'tail',tuple(round(x,4) for x in b.tail_local),'parent',b.parent.name if b.parent else None)
print('rigmat',r.matrix_world)
