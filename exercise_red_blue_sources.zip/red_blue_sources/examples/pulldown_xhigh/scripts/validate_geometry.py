import bpy,json,numpy as np,math
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output'
bpy.ops.wm.open_mainfile(filepath=str(OUT/'lat_pulldown_xhigh.blend'))
s=bpy.context.scene;h=bpy.data.objects['Human'];rig=bpy.data.objects['Human.rig'];bar=bpy.data.objects['Lat bar animated assembly']
n=len(h.data.vertices);r=np.empty(n*3);h.data.vertices.foreach_get('co',r);r=r.reshape(-1,3)
head=r[:,2]>1.48;body=(r[:,2]>1.0)&(r[:,2]<1.43)&(abs(r[:,0])<.16);hands=(abs(r[:,0])>.44)&(r[:,2]<1.12)&(r[:,2]>.90);feet=r[:,2]<.10
res=[]
for f in [1,11,21,31,41,51,61,71,81]:
 s.frame_set(f);dep=bpy.context.evaluated_depsgraph_get();ev=h.evaluated_get(dep);mesh=ev.to_mesh();co=np.empty(n*3);mesh.vertices.foreach_get('co',co);co=co.reshape(-1,3)
 by,bz=bar.location.y,bar.location.z;rad=np.sqrt((co[:,1]-by)**2+(co[:,2]-bz)**2)
 seat=(abs(co[:,0])<.21)&(co[:,1]>-.165)&(co[:,1]<.195)&(co[:,2]>.30)&(co[:,2]<.60)
 pad=(abs(co[:,0])>.045)&(abs(co[:,0])<.30)&(co[:,2]<.85);padrad=np.sqrt((co[:,1]+.31)**2+(co[:,2]-.6795)**2)
 row={'frame':f,'head_bar_min_surface_m':float(np.min(rad[head])-.0145),'torso_bar_min_surface_m':float(np.min(rad[body])-.0145),'hand_bar_min_surface_m':float(np.min(rad[hands])-.0145),'hand_vertices_inside_bar':int(np.sum(hands&(rad<.0145))),'seat_body_min_z':float(np.min(co[seat,2])),'pad_body_min_radial_m':float(np.min(padrad[pad])),'pad_penetrating_vertices':int(np.sum(pad&(padrad<.075))),'foot_min_z':float(np.min(co[feet,2]))}
 res.append(row);ev.to_mesh_clear();print(row,flush=True)
(OUT/'geometry_validation.json').write_text(json.dumps(res,indent=2))
