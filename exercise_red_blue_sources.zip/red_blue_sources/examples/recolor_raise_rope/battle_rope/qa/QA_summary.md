# Alternating battle-rope waves recolor QA

- 960×960; 96 decoded GIF frames; 4-second loop. Original timing retained.
- Every unique phase reviewed in the PNG and decoded-GIF contact sheets; representative checked at full size.
- Front/back anatomical masks checked before animation.
- Both red and blue remain visible in every decoded frame. Minimum red pixels: 2599; minimum blue pixels: 10665.
- Full body and apparatus remain inside frame; minimum edge margin: 47 pixels.
- Every exact-white source background pixel remains white in the decoded GIF; zero mismatches.
- Zero strong red/blue pixels introduced into neutral source regions. Black clothing stays neutral.
- Palette preserves separate neutral, red and blue shade ranges, with a fixed exact-white entry and class-constrained quantization.
- Geometry, topology, animation keyframes, rig, camera, clothing and frame settings match the source scene exactly. See scene_identity.json.
- GIF SHA-256: 270aec2a0365fee5f970e384b5ec432dbaaedbfe39c42e48437ace3264e97ac1.

Files: output/representative.png; qa/front_mask.png; qa/back_mask.png; qa/all_frames.png; qa/all_decoded_gif_frames.png; qa/decoded_gif_representative.png.
