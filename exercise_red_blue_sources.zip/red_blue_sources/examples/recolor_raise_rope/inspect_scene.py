import bpy,json,numpy as np
from pathlib import Path
R=Path(__file__).resolve().parent
bpy.ops.wm.open_mainfile(filepath=str(R.parent/'xhigh/output/lateral_raise_xhigh.blend'))
h=bpy.data.objects['Human'];rig=bpy.data.objects['Human.rig'];s=bpy.context.scene
print('BONES',json.dumps({n:{'head':list(rig.data.bones[n].head_local),'tail':list(rig.data.bones[n].tail_local)} for n in ['upperarm_l','lowerarm_l','thigh_l','spine_01','spine_02']}))
print('CAM',list(s.camera.location),list(s.camera.rotation_euler),s.camera.data.ortho_scale)
print('ATTR',[(a.name,a.domain,a.data_type) for a in h.data.color_attributes])
print('OBJECT',list(h.location),list(h.scale))
print('COLORS', [list(h.data.color_attributes[0].data[i].color) for i in range(0,1000,100)])
print('MOD',[(m.name,m.type) for m in h.modifiers])
