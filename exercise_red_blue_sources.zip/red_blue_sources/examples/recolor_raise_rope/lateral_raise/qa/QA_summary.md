# Lateral raise recolor QA

- 960×960; 36 decoded GIF frames; 3-second loop. Original timing retained.
- Every unique phase reviewed in the PNG and decoded-GIF contact sheets; representative checked at full size.
- Front/back anatomical masks checked before animation.
- Both red and blue remain visible in every decoded frame. Minimum red pixels: 1534; minimum blue pixels: 854.
- Full body and apparatus remain inside frame; minimum edge margin: 68 pixels.
- Every exact-white source background pixel remains white in the decoded GIF; zero mismatches.
- Zero strong red/blue pixels introduced into neutral source regions. Black clothing stays neutral.
- Palette preserves separate neutral, red and blue shade ranges, with a fixed exact-white entry and class-constrained quantization.
- Geometry, topology, animation keyframes, rig, camera, clothing and frame settings match the source scene exactly. See scene_identity.json.
- GIF SHA-256: 668be967689eb69476601a7f3b6021f11ec5e36008c222ab47a0094c21638ad6.

Files: output/representative.png; qa/front_mask.png; qa/back_mask.png; qa/all_frames.png; qa/all_decoded_gif_frames.png; qa/decoded_gif_representative.png.
