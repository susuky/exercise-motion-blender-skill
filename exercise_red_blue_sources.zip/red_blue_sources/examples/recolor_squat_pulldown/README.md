# 深蹲／滑輪下拉配色修正版

主要肌群紅色，次要與穩定肌群藍色，其餘灰色。白底、無文字、獨立黑短褲。

每支動畫：960 × 960、80 幀、20 fps、4 秒無限循環。保留原先人體、器材、動作、肌肉浮雕、視角及反鋸齒設定。

## 檔案

- squat/output/barbell_squat_xhigh_recolored.gif
- pulldown/output/lat_pulldown_xhigh_recolored.gif
- 各 output/representative.png：底部／下拉端點代表幀
- 各 output/*_recolored.blend：可編輯修正版場景
- 各 qa/mask_front.png、mask_back.png、mask_side.png：綁定姿勢解剖遮罩檢查
- 各 output/all_80_frames.jpg：全部 80 幀檢視圖
- 各 qa/color_map_validation.json：幾何／動畫不變性與遮罩範圍
- 各 qa/all_frame_color_qa.json：逐幀邊界、紅藍像素與 GIF 時序
- ANATOMICAL_COLOR_MAP.md：逐肌群功能、動作階段、位置、衣物遮擋與來源

## 重製

環境：Blender 4.3.2、Python 3、NumPy、Pillow。來源封裝含原始完整動畫場景。

    blender -b -t 3 --python recolor.py -- squat patch
    blender -b -t 3 --python recolor.py -- squat stills
    blender -b -t 3 --python recolor.py -- squat render_mirror
    python package.py squat

將 squat 換成 pulldown 可重製滑輪下拉。render_mirror 先驗證所有動畫曲線在前後半段的對稱性，再重用對稱的畫面；完整輸出仍為 80 幀。也可用 render 逐幀渲染全部畫面。

原資產採 MPFB 衍生 CC0 人體，授權存於各 assets/LICENSE.ASSETS.md。新增程式、配色和文件隨來源封裝提供。
