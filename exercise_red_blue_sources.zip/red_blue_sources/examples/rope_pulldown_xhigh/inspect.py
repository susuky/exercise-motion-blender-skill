import bpy,json
bpy.ops.wm.open_mainfile(filepath='/workspace/scratch/2a666e37abc2/muscle_comparison/rope_pulldown_xhigh/assets/improved_human.blend')
r=bpy.data.objects['Human.rig']
for b in r.data.bones:
 print(b.name,tuple(round(v,4) for v in b.head_local),tuple(round(v,4) for v in b.tail_local),b.parent.name if b.parent else None)
print('OBJECTS',[(o.name,o.type) for o in bpy.data.objects])
