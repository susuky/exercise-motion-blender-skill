import bpy
from pathlib import Path
R=Path(__file__).resolve().parent;p=R/'output/battle_rope_xhigh.blend'
bpy.ops.wm.open_mainfile(filepath=str(p))
for a in bpy.data.actions:
 for fc in a.fcurves:
  if not any(m.type=='CYCLES' for m in fc.modifiers):fc.modifiers.new('CYCLES')
bpy.context.scene.frame_end=96;bpy.context.scene.frame_set(7);bpy.ops.wm.save_as_mainfile(filepath=str(p),compress=True)
