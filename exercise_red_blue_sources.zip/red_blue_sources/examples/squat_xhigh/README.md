# 槓鈴背蹲：xhigh

960 × 960、80 幀、20 fps、4 秒無限循環。白底，動畫沒有文字。

## 交付檔案

- `output/barbell_squat_xhigh.gif`：完整動畫
- `output/representative.png`：最低點代表幀
- `output/barbell_squat_xhigh.blend`：人體、槓鈴、材質、骨架與完整動畫
- `output/animation_contact_sheet.jpg`、`output/all_80_frames.jpg`：動作檢視圖
- `qa/grip_*`：兩手正面及背面握槓特寫
- `qa/upper_back_*`：上背承槓特寫
- `qa/feet_*`、`qa/side_*`：腳底與側面動作檢查
- `qa/all_frame_geometry_validation.json`：81 幀密集蒙皮與接觸檢查
- `output/gif_validation.json`：GIF 規格及逐幀畫面邊界檢查

## 重製

環境：Blender 4.3.2、Python 3、Pillow、NumPy。

    blender -b -t 3 --python build_scene.py -- --stills
    blender -b -t 3 --python scripts/render.py
    blender -b -t 3 --python scripts/render.py -- --qa
    blender -b -t 2 --python scripts/validate_all.py
    python scripts/make_qa_sheets.py
    python package.py --archive

已有完整 `.blend` 時，可直接從第二行重新渲染。

## 人體及動作

沿用先前改善的 856,194 頂點連續蒙皮人體，保留胸腹、手臂與腿部肌肉浮雕及肌束紋理。黑色短褲為獨立蒙皮布料殼，具幾何厚度。本版本將主要紅色強調放在股四頭肌。

動作採高槓背蹲：66 公分握距，雙腳約 41 公分踝距、腳尖外開 15°，槓鈴置於上背斜方肌區域。雙腳固定，髖膝同步屈伸，最低點髖關節中心低於膝關節中心約 4.5 公分。軀幹隨深度由 12° 前傾至 36°，槓鈴保持在固定的足部支撐範圍上方。下降和起身各 2 秒，端點速度為零。

握槓由兩節手臂幾何、掌部方向、逐節指骨與實際皮膚表面共同求解。先將槓鈴擬合到上背表面，再分別調整食指、中指、無名指、小指及拇指的接觸。腕部保持輕微自然偏斜。腳底權重固定到足部，腳踝上方保留平滑過渡。

槓鈴是水平直槓，包含 29 mm 握持段、50 mm 套筒、兩側槓片、金屬輪轂與鎖環。握持段與光面段採相鄰幾何，避免重疊表面閃爍。

固定三分之四視角，完整人體與槓鈴全程入鏡。Workbench 16 級抗鋸齒。上升是下降的精確時間反向；渲染 41 個相位後鏡像排列，保留全部 80 個輸出影格和完整 Blender 時間軸。GIF 使用全片共用色盤。

## 資產

基礎人體為之前樣本使用的 MPFB 衍生 CC0 資產，授權全文位於 `assets/LICENSE.ASSETS.md`。`assets/improved_human.blend` 是此次沿用的高細節人體與短褲。場景沒有外部貼圖或網路相依。
