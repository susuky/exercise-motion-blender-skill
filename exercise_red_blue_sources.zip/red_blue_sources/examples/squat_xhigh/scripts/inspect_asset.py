import bpy, numpy as np,json
from pathlib import Path
P=Path(__file__).resolve().parents[1]
bpy.ops.wm.open_mainfile(filepath=str(P/'assets/improved_human.blend'))
r=bpy.data.objects['Human.rig']
for b in r.data.bones:
 print(b.name,tuple(round(v,4) for v in b.head_local),tuple(round(v,4) for v in b.tail_local),round(b.length,4),b.parent.name if b.parent else 'None')
h=bpy.data.objects['Human'];a=np.array([v.co[:] for v in h.data.vertices])
for z0,z1 in [(1.39,1.41),(1.41,1.43),(1.43,1.45),(1.45,1.47)]:
 for x0,x1 in [(0,.03),(.03,.06),(.06,.10),(.1,.14),(.14,.18),(.18,.22)]:
  sel=(a[:,2]>z0)&(a[:,2]<z1)&(abs(a[:,0])>x0)&(abs(a[:,0])<x1)
  if sel.any():print('BACK',z0,z1,x0,x1,'maxY',a[sel,1].max())
print('obj transforms',r.matrix_world,h.matrix_world)
print('foot min',a[a[:,2]<.1,2].min())
