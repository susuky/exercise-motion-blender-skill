"""Contact-sheet assembly for the rendered closeups."""
from PIL import Image
from pathlib import Path
p=Path(__file__).resolve().parents[1]/'qa'
for view in ['grip','grip_front']:
 sheet=Image.new('RGB',(1440,960),'white')
 for k,(side,f) in enumerate([(s,f) for s in ['l','r'] for f in [1,21,41]]):
  im=Image.open(p/f'{view}_{side}_{f:03}.png').convert('RGB').resize((480,480),Image.Resampling.LANCZOS);sheet.paste(im,((k%3)*480,(k//3)*480))
 sheet.save(p/f'{view}_contact_sheet.jpg',quality=94)
sheet=Image.new('RGB',(1440,1440),'white')
for k,(view,f) in enumerate([(view,f) for view in ['upper_back','feet','side'] for f in [1,21,41]]):
 im=Image.open(p/f'{view}_{f:03}.png').convert('RGB').resize((480,480),Image.Resampling.LANCZOS);sheet.paste(im,((k%3)*480,(k//3)*480))
sheet.save(p/'support_contact_sheet.jpg',quality=94)
