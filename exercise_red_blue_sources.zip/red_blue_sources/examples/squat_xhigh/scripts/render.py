"""Render the 80-frame cycle or targeted contact closeups (--qa)."""
import bpy,sys,json,shutil
from pathlib import Path
from mathutils import Vector as V
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output';QA=ROOT/'qa'
bpy.ops.wm.open_mainfile(filepath=str(OUT/'barbell_squat_xhigh.blend'))
s=bpy.context.scene;cam=s.camera;orig=(cam.location.copy(),cam.rotation_euler.copy(),cam.data.ortho_scale)
records=json.loads((OUT/'motion.json').read_text())
def look(target,offset,scale,path):
 cam.location=target+offset;cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=scale;s.render.filepath=str(path);bpy.ops.render.render(write_still=True)
if '--qa' in sys.argv or '--legs-qa' in sys.argv:
 for f in [1,21,41]:
  s.frame_set(f);row=records[f-1];bar=V(row['bar'])
  for side,sign in ([] if '--legs-qa' in sys.argv else [('l',1),('r',-1)]):
   target=V(row['joints']['grip_'+side]);look(target,V((.24*sign,.48,.21)),.31,QA/f'grip_{side}_{f:03d}.png')
   look(target,V((.20*sign,-.48,.13)),.31,QA/f'grip_front_{side}_{f:03d}.png')
  if '--legs-qa' not in sys.argv:look(bar,V((.35,.65,.26)),.62,QA/f'upper_back_{f:03d}.png')
  look(V((0,-.015,.10)),V((1.0,-1.7,.42)),.66,QA/f'feet_{f:03d}.png')
  look(V((0,-.01,.84)),V((3.3,0,.2)),2.05,QA/f'side_{f:03d}.png')
else:
 start,end=1,42
 if '--range' in sys.argv:
  idx=sys.argv.index('--range');start,end=int(sys.argv[idx+1]),int(sys.argv[idx+2])
 for f in range(start,end):
  s.frame_set(f);s.render.filepath=str(OUT/f'frame_{f:03d}.png');bpy.ops.render.render(write_still=True)
 # The ascent is the exact time reverse of the controlled descent.
 for f in ([] if '--range' in sys.argv else range(42,81)):shutil.copy2(OUT/f'frame_{82-f:03d}.png',OUT/f'frame_{f:03d}.png')
 if '--range' not in sys.argv:shutil.copy2(OUT/'frame_041.png',OUT/'representative.png')
print('RENDER COMPLETE',flush=True)
