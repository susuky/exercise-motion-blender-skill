# 相撲槓鈴硬舉：xhigh

960 × 960、80 幀、20 fps、4 秒無限循環。白底，動畫沒有文字。

## 交付檔案

- `output/sumo_deadlift_xhigh.gif`：完整動畫
- `output/representative.png`：槓片落地、準備起槓的代表幀
- `output/sumo_deadlift_xhigh.blend`：人體、槓鈴、材質、骨架與完整動畫
- `output/animation_contact_sheet.jpg`、`output/all_80_frames.jpg`：動作檢視圖
- `qa/grip_*`：兩手正面及背面握槓特寫；鎖定的背面特寫暫時隱藏遮擋手掌的軀幹與腿部
- `qa/feet_*`、`qa/knees_*`、`qa/side_*`：腳底、膝蓋與側面動作檢查
- `qa/all_frame_geometry_validation.json`：81 幀密集蒙皮與接觸檢查
- `output/gif_validation.json`：GIF 規格及逐幀畫面邊界檢查

## 重製

環境：Blender 4.3.2、Python 3、Pillow、NumPy。

    blender -b -t 2 --python build_scene.py -- --stills
    blender -b -t 2 --python scripts/render.py
    blender -b -t 2 --python scripts/render.py -- --qa
    blender -b -t 2 --python scripts/validate_all.py
    blender -b -t 1 --python scripts/check_hand_leg_clearance.py
    blender -b -t 2 --python scripts/check_muscle_map.py
    python scripts/make_qa_sheets.py
    python package.py --archive

已有完整 `.blend` 時，可直接從第二行重新渲染。

## 人體及動作

沿用先前改善的 856,194 頂點連續蒙皮人體，保留胸腹、手臂與腿部肌肉浮雕及肌束紋理。黑色短褲為獨立蒙皮布料殼，具幾何厚度。肌群配色採主力紅、輔助藍、其餘灰。

- 紅色：股四頭肌的膝伸展區；以大收肌為重點的近端內後側髖伸展區；臀大肌區（由黑色短褲遮蔽）。
- 藍色：腿後肌群輔助髖伸展，腰部豎脊肌維持中立脊柱。
- 灰色：其他皮膚肌群。短褲保持黑色。

配色按動作角色分類，保留肌束和光影。內收區採局部表面範圍，聚焦大收肌的髖伸展貢獻。每個區域的遮罩範圍及顏色參數記錄在 `muscle_mapping.json`，正背面檢查圖位於 `qa/muscle_map_front.png` 和 `qa/muscle_map_rear.png`。

雙腳踝距 90 公分，腳尖向外 45°，雙手採正握並位於大腿內側。起槓時膝蓋沿腳尖方向打開，髖略高於膝。髖膝同步伸展，軀幹由前傾 45° 回到直立鎖定。肘部全程伸直，手腕沿前臂延伸。鎖定時軀幹直立，膝接近伸直。

槓鈴中心沿固定垂直線從 22.5 公分升至 71.394 公分。最大槓片半徑 22.5 公分，起點落地。上升及下降各 2 秒，端點速度為零。雙腳固定，兩手始終握著同一根直槓。

握槓由肩、肘、腕、掌部方向與逐節指骨共同求解，再分別依密集皮膚表面調整食指、中指、無名指、小指及拇指。腳底權重固定到足部，腳踝上方保留平滑過渡。大腿和小腿的轉向與外開腳掌一致。

槓鈴包含 29 mm 握持段、50 mm 套筒、兩側槓片、金屬輪轂與鎖環。固定三分之四視角，全身與槓鈴全程入鏡。Workbench 16 級抗鋸齒。下降為上升的精確時間反向；渲染 41 個相位後鏡像排列，保留全部 80 個輸出影格及完整 Blender 時間軸。GIF 使用全片共用色盤。

## 資產

基礎人體為之前樣本使用的 MPFB 衍生 CC0 資產，授權全文位於 `assets/LICENSE.ASSETS.md`。`assets/improved_human.blend` 是此次沿用的高細節人體與短褲。場景沒有外部貼圖或網路相依。
