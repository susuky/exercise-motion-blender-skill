import bpy,json,numpy as np
from pathlib import Path
from mathutils import Vector as V
R=Path(__file__).resolve().parents[1];bpy.ops.wm.open_mainfile(filepath=str(R/'output/sumo_deadlift_xhigh.blend'));s=bpy.context.scene;s.frame_set(21);cam=s.camera;h=bpy.data.objects['Human'];c=np.empty(len(h.data.vertices)*4);h.data.color_attributes['Anatomical fibres'].data.foreach_get('color',c);c=c.reshape(-1,4)
red=(c[:,0]>c[:,1]+.08)&(c[:,0]>c[:,2]+.08);blue=(c[:,2]>c[:,0]+.08)&(c[:,2]>c[:,1]+.04)
r=np.array([v.co[:] for v in h.data.vertices]);stats={'primary_red_skin_vertices':int(red.sum()),'secondary_blue_skin_vertices':int(blue.sum()),'primary_red_rest_bounds_m':r[red].min(0).tolist()+r[red].max(0).tolist(),'secondary_blue_rest_bounds_m':r[blue].min(0).tolist()+r[blue].max(0).tolist(),'clothing':'Separate opaque Black shorts object; no muscle vertex attribute was written to clothing.'}
(R/'qa/muscle_color_validation.json').write_text(json.dumps(stats,indent=2))
for name,loc in [('front',V((3.8,-7.2,2.7))),('rear',V((3.8,7.2,2.7)))]:
 cam.location=loc;cam.rotation_euler=(V((0,-.02,.78))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=2.2;s.render.filepath=str(R/f'qa/muscle_map_{name}.png');bpy.ops.render.render(write_still=True)
print(json.dumps(stats,indent=2),flush=True)
