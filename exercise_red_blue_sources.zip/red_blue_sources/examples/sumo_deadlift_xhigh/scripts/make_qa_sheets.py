from pathlib import Path
from PIL import Image,ImageDraw
ROOT=Path(__file__).resolve().parents[1];QA=ROOT/'qa'
for name,files,cols in [('grip_contact_sheet',sorted(QA.glob('grip_*.png')),4),('feet_knees_side_contact_sheet',sorted(QA.glob('feet_*.png'))+sorted(QA.glob('knees_*.png'))+sorted(QA.glob('side_*.png')),3)]:
 if not files:continue
 w,h=400,425;sheet=Image.new('RGB',(w*cols,h*((len(files)+cols-1)//cols)),'white');dr=ImageDraw.Draw(sheet)
 for i,p in enumerate(files):
  x=(i%cols)*w;y=(i//cols)*h;sheet.paste(Image.open(p).resize((400,400),Image.Resampling.LANCZOS),(x,y));dr.text((x+8,y+404),p.stem,fill=(0,0,0))
 sheet.save(QA/(name+'.jpg'),quality=94)
