import bpy,json
from pathlib import Path
from mathutils import Vector as V
R=Path(__file__).resolve().parents[1];bpy.ops.wm.open_mainfile(filepath=str(R/'output/sumo_deadlift_xhigh.blend'));s=bpy.context.scene;s.frame_set(41);cam=s.camera;j=json.loads((R/'output/motion.json').read_text())[40]['joints']
h=bpy.data.objects['Human'];group=h.vertex_groups.new(name='QA isolated hands');group.add([v.index for v in h.data.vertices if abs(v.co.x)>.43 and .87<v.co.z<1.16],1,'REPLACE');mask=h.modifiers.new('QA isolate palms for rear inspection','MASK');mask.vertex_group=group.name;bpy.data.objects['Black shorts'].hide_render=True
for side,sign in [('l',1),('r',-1)]:
 target=V(j['grip_'+side]);cam.location=target+V((.20*sign,.48,-.05));cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=.31;s.render.filepath=str(R/f'qa/grip_back_{side}_041.png');bpy.ops.render.render(write_still=True)
