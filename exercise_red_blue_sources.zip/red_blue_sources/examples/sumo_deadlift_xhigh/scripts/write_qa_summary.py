from pathlib import Path
import json
R=Path(__file__).resolve().parents[1];g=json.loads((R/'qa/all_frame_geometry_validation.json').read_text())['summary'];v=json.loads((R/'output/gif_validation.json').read_text())['gif']
hand_leg=json.loads((R/'qa/hand_leg_clearance.json').read_text());hand_gap=min(x['minimum_signed_distance_for_nearby_points_m'] for x in hand_leg)
text=f'''# 相撲硬舉 QA

## 輸出

- {v['size'][0]} × {v['size'][1]}，{v['frame_count']} 幀，{v['duration_ms']/1000:g} 秒，無限循環
- 固定視角、白底、沒有字幕；全身和槓鈴逐幀完整入鏡
- 共用 GIF 色盤；循環端點速度為零

## 幾何與接觸

逐一檢查 80 個動作影格與第 81 幀重複端點，每幀 {g['skin_vertices']:,} 個皮膚頂點。

- 皮膚進入槓身的頂點：{g['all_skin_vertices_inside_shaft_max']}
- 皮膚進入槓片的頂點：{g['skin_inside_plate_vertices_max']}
- 手部至槓身最小表面間隙：{g['hand_shaft_min_clearance_m']*1000:.3f} mm
- 手指至大腿最小表面間隙：{hand_gap*1000:.3f} mm；41 個獨立姿勢全數通過，回程為相同姿勢反向排列
- 下半身至槓身最小表面間隙：{g['lower_body_shaft_min_clearance_m']*1000:.3f} mm
- 腳底最大位移：{g['sole_max_displacement_m']*1000:.6f} mm
- 腳底最低點：{g['sole_min_z_m']*1000:.3f} mm
- 槓路水平漂移：{g['bar_horizontal_drift_m']*1000:.6f} mm
- 首末端點最大頂點差：{g['full_cycle_max_vertex_difference_m']*1000:.6f} mm
- 雙肘角度：{g['elbow_angle_range_degrees'][0]:.5f}–{g['elbow_angle_range_degrees'][1]:.5f}°
- 手腕與前臂最大方向差：{g['wrist_alignment_max_degrees']:.6f}°
- 鎖定時膝屈曲：約 {g['knee_flexion_lockout_degrees']['l']:.2f}°
- 雙手位於膝內側，最小橫向間距：{g['hands_inside_knees_margin_m']*100:.2f} cm
- 起槓時髖比膝高：{g['bottom_hip_minus_knee_z_m']['l']*100:.2f} cm
- 起槓槓片接地；槓心從 {g['bar_height_range_m'][0]*100:.3f} cm 升至 {g['bar_height_range_m'][1]*100:.3f} cm

## 肌群圖例

- 主力紅：股四頭肌、以大收肌為重點的近端內後側髖伸展區、臀大肌區
- 輔助藍：腿後肌群協助髖伸展，豎脊肌維持中立脊柱
- 其餘灰；黑色短褲遮蔽臀部

配色按動作角色分類。區域遮罩、角色與色彩參數見 `muscle_mapping.json`；正背面檢查圖見 `qa/muscle_map_front.png`、`qa/muscle_map_rear.png`。

## 目視檢查

檢查起槓、中段、鎖定關鍵幀及 80 幀總覽，再檢查雙手正反面特寫、腳底、膝蓋和側面。鎖定的背面握持特寫暫時隱藏遮擋手掌的軀幹與腿部，保留原始手與槓的幾何。

- 寬站距、腳尖外開，屈膝方向與腳掌一致
- 腳底固定，髖膝連續伸展；軀幹在鎖定位置直立
- 雙手保持正握並包住同一根槓身
- 槓片在起點落地，槓身沿固定垂直線通過腿部前方
- 完整模型保留連續皮膚、肌肉浮雕、細肌束和黑色短褲

完整數據：`qa/all_frame_geometry_validation.json`、`output/gif_validation.json`。
'''
(R/'QA_summary.md').write_text(text)
