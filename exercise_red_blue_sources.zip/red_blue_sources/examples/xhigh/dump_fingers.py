exec(open(__file__.replace('dump_fingers.py','inspect_grip.py')).read().split('groups={')[0])
for finger in ['index','middle','ring','pinky','thumb']:
 print(finger)
 for k in range(1,4):
  b=r.pose.bones[f'{finger}_{k:02}_l']
  for p in [b.head,b.tail]:
   d=p-w;print([round(d.dot(a),4) for a in [dx,dy,dz]],end=' ')
  print()
