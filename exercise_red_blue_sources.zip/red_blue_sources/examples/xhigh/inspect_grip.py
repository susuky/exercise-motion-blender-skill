import bpy,numpy as np
from pathlib import Path
from mathutils import Vector as V
R=Path(__file__).resolve().parent;bpy.ops.wm.open_mainfile(filepath=str(R/'output/lateral_raise_xhigh.blend'));s=bpy.context.scene;s.frame_set(19);h=bpy.data.objects['Human'];r=bpy.data.objects['Human.rig'];root=bpy.data.objects['Dumbbell l'];w=r.pose.bones['hand_l'].head.copy();dy=(r.pose.bones['middle_01_l'].head-w).normalized();dx=root.matrix_world.to_3x3()@V((0,1,0));dz=dx.cross(dy).normalized();ev=h.evaluated_get(bpy.context.evaluated_depsgraph_get());me=ev.to_mesh();groups={g.index:g.name for g in h.vertex_groups};pts=[]
for v in h.data.vertices:
 wt=sum(g.weight for g in v.groups if groups[g.group].endswith('_l') and groups[g.group].startswith(('hand_','index_','middle_','ring_','pinky_','thumb_')))
 if wt>.7:
  p=h.matrix_world@me.vertices[v.index].co-w;pts.append((p.dot(dx),p.dot(dy),p.dot(dz)))
np.save(R/'output/hand_points.npy',np.array(pts));ev.to_mesh_clear();print('PTS',len(pts))
