exec(open(__file__.replace('locate_contact.py','inspect_grip.py')).read().split('groups={')[0])
from collections import Counter
cnt=Counter();closest=[];inv=root.matrix_world.inverted();groups={g.index:g.name for g in h.vertex_groups}
for v in h.data.vertices:
 if v.co.x<.4:continue
 p=inv@(h.matrix_world@me.vertices[v.index].co);rad=(p.x*p.x+p.z*p.z)**.5
 if abs(p.y)<.074 and rad<.013:
  name=groups[max([g for g in v.groups if groups[g.group] in r.pose.bones],key=lambda g:g.weight).group];cnt[name]+=1;closest.append((rad,v.index,name))
print('CONTACT',cnt);print(sorted(closest)[:10])
