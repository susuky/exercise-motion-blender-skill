import bpy,time
from pathlib import Path
from mathutils import Vector as V
R=Path(__file__).resolve().parent;O=R/'output'
bpy.ops.wm.open_mainfile(filepath=str(O/'lateral_raise_xhigh.blend'))
s=bpy.context.scene;s.display.render_aa='8'
for m in bpy.data.objects['Black shorts'].modifiers:
 if m.type=='BEVEL':m.show_render=False
print('BEGIN',flush=True)
s.frame_set(19);s.render.filepath=str(O/'preview.png');bpy.ops.render.render(write_still=True)
print('END',flush=True)
