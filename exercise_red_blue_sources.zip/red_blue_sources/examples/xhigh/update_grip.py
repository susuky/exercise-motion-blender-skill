import bpy,math,json,sys
from pathlib import Path
from mathutils import Vector as V, Matrix,Quaternion
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'output';bpy.ops.wm.open_mainfile(filepath=str(OUT/'lateral_raise_xhigh.blend'));h=bpy.data.objects['Human'];rig=bpy.data.objects['Human.rig'];bones=rig.data.bones;rest={b.name:b.matrix_local.copy() for b in bones};weights=[bpy.data.objects['Dumbbell '+s] for s in ['l','r']];expanded=json.loads((ROOT/'assets/motion.json').read_text())
src=(ROOT/'build_render.py').read_text();exec(src[src.index('def segment('):src.index('scene=bpy.context.scene;')])
scene=bpy.context.scene;scene.frame_set(19);bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'lateral_raise_xhigh.blend'),compress=True)
if '--no-render' in sys.argv:sys.exit(0)
cam=scene.camera
for i,side in enumerate(['l','r']):
 cam.location=weights[i].location+V((.30 if i==0 else -.30,-.48,.22));cam.rotation_euler=(weights[i].location-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=.37;scene.render.filepath=str(OUT/f'hand_{side}_check.png');bpy.ops.render.render(write_still=True)
